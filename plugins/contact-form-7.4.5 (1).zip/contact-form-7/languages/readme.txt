== For Translators ==

We are in the process of migrating translations to translate.wordpress.org.

http://contactform7.com/2016/01/08/translations-migrate-to-translate-wordpress-org/

The language files in this directory will no longer be updated and will be removed at some point in the future.

Thank you for your past contribution, and see you at translate.wordpress.org :)
