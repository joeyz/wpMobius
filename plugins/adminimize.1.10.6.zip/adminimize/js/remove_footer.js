/**
 * remove footer
 */
jQuery(document).ready( function( $ ) {
	$( '#footer, #footer-left, #footer-upgrade' ).remove();
} );
